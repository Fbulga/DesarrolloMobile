
public interface IManager
{
    void ResetManager();
}