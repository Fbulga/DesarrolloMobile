
public interface IBreakable
{
    void DestroyMe();
    void TryDestroyMe();
}
