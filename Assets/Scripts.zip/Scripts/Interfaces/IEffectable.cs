
using UnityEngine;

public interface IEffectable
{
    public void Execute(GameObject gameObject);   
}
